package com.example.currencyconverter;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    public void convertCurrency(View view){
        EditText editText = (EditText)findViewById(R.id.editTextNumberDecimal);
        String amount = editText.getText().toString();
        double amt = Double.parseDouble(amount);
        double amountInDollars =  amt* 0.0136;
//        String amountInDollar = Double.toString(amountInDollars);
        String amountInDollar = String.format("%.2f",amountInDollars);
        Log.i("Amount in Dollars",amountInDollar);
        Toast.makeText(this, "Hi, Your dollar amount is "+ amountInDollar, Toast.LENGTH_SHORT).show();

    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
}