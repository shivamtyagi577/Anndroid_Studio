package com.example.junkfoodcourt;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.graphics.ColorSpace;
import android.os.Bundle;

import java.util.ArrayList;
import java.util.List;

public class MainActivity2 extends AppCompatActivity {
    RecyclerView recyclerView;
    LinearLayoutManager layoutManager;
    List<ModelClass> userList;
    Adapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        initData();
        initRecyclerView();

    }

    private void initRecyclerView() {
        recyclerView = findViewById(R.id.recyclerview);
        layoutManager = new LinearLayoutManager(this);
        layoutManager.setOrientation(RecyclerView.VERTICAL);
        recyclerView.setLayoutManager(layoutManager);
        adapter = new Adapter(userList);
        recyclerView.setAdapter(adapter);
        adapter.notifyDataSetChanged();
    }

    private void initData() {
        userList = new ArrayList<>();

        userList.add(new ModelClass(R.drawable.f1,"Burger House","Closes at 11 pm","Available","____________________________________"));
        userList.add(new ModelClass(R.drawable.f2,"Doughnut Plaza","Closes at 11 pm","Available","____________________________________"));
        userList.add(new ModelClass(R.drawable.f3,"Pop Corn Room","Closes at 5 pm","Unavailable","____________________________________"));
        userList.add(new ModelClass(R.drawable.f4,"Samosa","Closes at 5 pm","Available","____________________________________"));
        userList.add(new ModelClass(R.drawable.f5,"Pizza Hut","Closes at 8 pm","Available","____________________________________"));
        userList.add(new ModelClass(R.drawable.f1,"Burger King","Closes at 7 pm","Unavailable","____________________________________"));
        userList.add(new ModelClass(R.drawable.f2,"Doughnut Pep","Closed","Unavailable","____________________________________"));
        userList.add(new ModelClass(R.drawable.f3,"PopCorn Slap","Closes at 5p m","Available","____________________________________"));
        userList.add(new ModelClass(R.drawable.f5,"Pizza Spicy","Closes at 5 pm","Available","____________________________________"));


    }
}