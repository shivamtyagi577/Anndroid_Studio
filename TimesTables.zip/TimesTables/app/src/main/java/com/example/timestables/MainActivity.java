package com.example.timestables;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.SeekBar;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    SeekBar seek_Bar ;
    ListView listView;
    int maxValue = 20;
    int currValue = 10;
//    int timesTableNumber;

    public void generate(int timesTableNumber){
        ArrayList<String> timesTableContent = new ArrayList<String>();
        for(int i = 1; i <= 15; i++){
            timesTableContent.add(Integer.toString(i * timesTableNumber));
        }
        ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>(this, android.R.layout.select_dialog_item,timesTableContent);
        listView.setAdapter(arrayAdapter);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        seek_Bar = findViewById(R.id.seekBar);
        listView = findViewById(R.id.list_view);
        seek_Bar.setMax(maxValue);
        seek_Bar.setProgress(currValue);

        seek_Bar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                int min = 1;
                int timesTableNumber;
                if(progress < min){
                    timesTableNumber = min;
                    seek_Bar.setProgress(min);
                }
                else{
                   timesTableNumber = progress;
                }

                generate(timesTableNumber);

            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });

    }
}