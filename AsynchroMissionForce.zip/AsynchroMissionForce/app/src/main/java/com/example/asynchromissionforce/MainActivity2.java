package com.example.asynchromissionforce;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;

import java.util.Random;

public class MainActivity2 extends AppCompatActivity {

    Context context;
    EditText editText;
    Button button;
    Dialog dialog;
    int arr[]={1,23,43,45,46,22,12,56,67,55};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        this.context = this;
        editText = (EditText) findViewById(R.id.editText);
        button = (Button) findViewById(R.id.button);
        dialog = new Dialog(this);


        Random rn = new Random();
        int answer = rn.nextInt(10) + 1;

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(editText != null && editText.length() > 0) {
                    new SimpleAsyncTask(context).execute(editText.getText().toString());
//                    for(int i=0;i<arr.length;i++){
//                        if(answer==arr[i]){
//                            openWinDialog();
//                        }
//                        else{
//                            //openLoseDialog();
//                            openWinDialog();
//                        }
//                    }
                }
            }
        });


//        for(int i =0; i < 100; i++)
//        {
//            int answer = rn.nextInt(10) + 1;
//            //System.out.println(answer);
//        }
    }
    public void openWinDialog(){
        dialog.setContentView(R.layout.win_layout_dialog);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));

        Button button = findViewById(R.id.buttonok);
        dialog.show();

    }
    public void openLoseDialog(){

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main, menu);
        return super.onCreateOptionsMenu(menu);
    }
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch(item.getItemId()){
            case R.id.git :
                String url="https://github.com/shivamtyagi577/Anndroid_Studio/blob/main/Async%20Task.pdf";
                Intent intent=new Intent(Intent.ACTION_VIEW);
                intent.setData(Uri.parse(url));
                startActivity(intent);
        }
        return super.onOptionsItemSelected(item);
    }


}

