package com.example.higher_and_lower;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import java.util.Random;


public class MainActivity extends AppCompatActivity {

    int random_number;
    public void generator(){
        Random rand = new Random();
        random_number = rand.nextInt(20) + 1;
    }


    public void guess(View view){
        EditText editText = (EditText)findViewById(R.id.editTextNumber);
        int guessValue = Integer.parseInt(editText.getText().toString());
        String message;
        if(guessValue < random_number){
            message="Higher";
        }
        else if(guessValue > random_number){
            message="Lower";
        }
        else{
            message = "Identical";
            generator();
        }
        Toast.makeText(this,message,Toast.LENGTH_LONG).show();

    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        generator();

    }
}