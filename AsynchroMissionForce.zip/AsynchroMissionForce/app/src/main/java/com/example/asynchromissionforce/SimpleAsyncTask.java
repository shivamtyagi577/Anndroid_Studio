package com.example.asynchromissionforce;

import android.app.ProgressDialog;
import android.content.Context;
import android.os.AsyncTask;
import android.util.Log;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Random;

public class SimpleAsyncTask  extends AsyncTask<String, String, String> {
    Context context;
    String result;
    ProgressDialog progressDialog;
    public SimpleAsyncTask (Context context) {
        this.context = context;
    }
    @Override
    protected void onPreExecute() {
        super.onPreExecute();
        progressDialog = ProgressDialog.show(context,
                "Result is .....", null);
    }
    @Override
    protected String doInBackground(String... args) {
//        int value = Integer.parseInt(args[0]);
        for(int i = 0; i <= 5 ;i++){
            try {
                Thread.sleep(1000);
            } catch (Exception e) {
                Log.v("Error: ", e.toString());
            }
            result = "Please wait for " + (5 - i ) + " seconds";
            publishProgress(result);
        }
        return null;
    }

    @Override
    protected void onProgressUpdate(String... text) {
        progressDialog.setMessage(text[0]);
    }
    protected void onPostExecute(String result) {
        progressDialog.dismiss();
    }
}