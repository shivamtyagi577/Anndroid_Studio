package com.example.trend;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class MainActivity5 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main5);
        ActionBar actionBar=getSupportActionBar();
        actionBar.setTitle("Profile Pic");
        actionBar.setDisplayHomeAsUpEnabled(true);
    }
}