package com.example.numbershapes;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    class Number{
        int number;
        public boolean isSquare(){
            double squareRoot = Math.sqrt(number);
            if(squareRoot == Math.floor(squareRoot)){
                return true;
            }
            else{
                return false;
            }
        }
        public boolean isTriangular(){
            int x = 1;
            int triangularNumber =1;
            while(triangularNumber < number ){
                x++;
                triangularNumber = triangularNumber + x;
            }
            if(triangularNumber == number){
                return true;
            }
            else{
                return false;
            }
        }
    }

    public void Test_Number(View view){
        EditText editText = (EditText) findViewById(R.id.editTextNumber);
        Number myNumber = new Number();
        myNumber.number = Integer.parseInt(editText.getText().toString());
        //myNumber.number = 25;
        //String message;
        String message = editText.getText().toString();
        if(myNumber.isSquare() && myNumber.isTriangular()){
//            message = editText.getText().toString() + "is square and triangular ";
            message +=  " is square and triangular ";
        }
        else if(myNumber.isSquare()){
            message += " is square but not triangle ";
        }
        else if(myNumber.isTriangular()){
           message += " is  triangular but not square ";
        }
        else{
            message += " is Neither";
        }
        //System.out.println(myNumber.isSquare());
        Toast.makeText(this,message,Toast.LENGTH_LONG).show();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
}