package com.example.covid_19testbookingapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.PopupMenu;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.bottomnavigation.BottomNavigationView;

import org.w3c.dom.Text;

public class MainActivity5 extends AppCompatActivity {
    private TextView textView4;
    private  long backPressedTime;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main5);
        textView4= (TextView)findViewById(R.id.textView4);


        textView4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                PopupMenu popup = new PopupMenu(MainActivity5.this,v);
                popup.getMenuInflater().inflate(R.menu.pop_call,popup.getMenu());
                popup.show();
                popup.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                    @Override
                    public boolean onMenuItemClick(MenuItem item) {
                        switch (item.getItemId()){
                            case R.id.mb1 :
                                Toast.makeText(MainActivity5.this,"Call me on Duo",Toast.LENGTH_LONG).show();
                                return true;
                            case R.id.mb2 :
                                Toast.makeText(MainActivity5.this,"Call me on Phone",Toast.LENGTH_LONG).show();
                                return true;

                        }
                        return false;
                    }
                });

            }
        });

        BottomNavigationView bottomNavigationView= (BottomNavigationView) findViewById(R.id.bottom_navigation);
        bottomNavigationView.setSelectedItemId(R.id.home);
        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                switch(item.getItemId()){
                    case R.id.booking:
                        startActivity(new Intent(getApplicationContext(),MainActivity3.class));
                        overridePendingTransition(0,0);
                        return true;
                    case R.id.status:
                        startActivity(new Intent(getApplicationContext(),MainActivity4.class));
                        overridePendingTransition(0,0);

                        return true;
                    case R.id.profile:

                        return true;
                }
                return false;
            }
        });
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main,menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch(item.getItemId()){
            case R.id.logout:
                openDialog();
                break;
        }
        return super.onOptionsItemSelected(item);
    }
    public void openDialog(){
        AlertDialog.Builder builder=new AlertDialog.Builder(this);
        builder.setTitle("Log Out ?");
        builder.setMessage("Are you sure do you want to quit?");
        builder.setCancelable(false);
        builder.setPositiveButton("Ok",null);
        builder.setNegativeButton("Cancel",null);
        builder.show();
    }

    @Override
    public void onBackPressed() {


        if(backPressedTime+ 3000 > System.currentTimeMillis()){
//            finishAffinity();
//            System.exit(0);
            super.onBackPressed();
            return;
        }
        else{
            Toast.makeText(getApplicationContext(),"Press back again to exit",Toast.LENGTH_SHORT).show();
            //isPressed=true;
        }
        backPressedTime=System.currentTimeMillis();
    }
}