package com.example.crickscore;

public class EmployeeModelClass {
    Integer id;
    String t1,st1,t2,st2,status,date;

    public EmployeeModelClass(String t1, String st1, String t2,String st2, String status, String date) {
        this.t1 = t1;
        this.st1 = st1;
        this.t2 = t2;
        this.st2 = st2;
        this.status = status;
        this.date = date;
    }

    public EmployeeModelClass(Integer id, String t1, String st1, String t2,String st2, String status, String date) {
        this.id = id;
        this.t1 = t1;
        this.st1 = st1;
        this.t2 = t2;
        this.st2 = st2;
        this.status = status;
        this.date = date;
    }

    public Integer getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }

    public String getT1() {
        return t1;
    }
    public void setT1(String t1) {
        this.t1 = t1;
    }

    public String getSt1() {
        return st1;
    }
    public void setSt1(String st1) {
        this.st1 = st1;
    }

    public String getT2() {
        return t2;
    }
    public void sett2(String t2) {
        this.t2 = t2;
    }

    public String getSt2() {
        return st2;
    }
    public void setSt2(String st2) {
        this.st2 = st2;
    }

    public String getStatus() {
        return status;
    }
    public void setStatus(String status) {
        this.status = status;
    }

    public String getDate() {
        return date;
    }
    public void setDate(String date) {
        this.date = date;
    }
}

