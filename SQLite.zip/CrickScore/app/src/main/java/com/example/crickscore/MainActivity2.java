package com.example.crickscore;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity2 extends AppCompatActivity {

//    @Override
//    protected void onCreate(Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//        setContentView(R.layout.activity_main2);
//    }

    EditText editText_t1, editText_st1, editText_t2, editText_st2, editText_status, editText_date;
    Button button_add, button_view;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        ActionBar actionBar=getSupportActionBar();
        actionBar.setTitle("Write Status of a match( IPL / ODI / T20)");
        //actionBar.s;

        editText_t1 = findViewById(R.id.edittext_t1);
        editText_st1 = findViewById(R.id.edittext_st1);
        editText_t2 = findViewById(R.id.edittext_t2);
        editText_st2 = findViewById(R.id.edittext_st2);
        editText_status = findViewById(R.id.edittext_status);
        editText_date = findViewById(R.id.edittext_date);

        button_add = findViewById(R.id.button_add);
        button_view = findViewById(R.id.button_view);

        button_add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String stringt1 = editText_t1.getText().toString();
                String stringst1 = editText_st1.getText().toString();
                String stringt2 = editText_t2.getText().toString();
                String stringst2 = editText_st2.getText().toString();
                String stringstatus = editText_status.getText().toString();
                String stringdate = editText_date.getText().toString();

                if (stringt1.length() <= 0 || stringt2.length() <= 0 || stringdate.length() <= 0 || stringstatus.length() <= 0) {
                    Toast.makeText(MainActivity2.this, "Enter All Data", Toast.LENGTH_SHORT).show();
                } else {
                    DatabaseHelperClass databaseHelperClass = new DatabaseHelperClass(MainActivity2.this);
                    EmployeeModelClass employeeModelClass = new EmployeeModelClass(stringt1, stringst1, stringt2, stringst2, stringstatus, stringdate);
                    databaseHelperClass.addEmployee(employeeModelClass);
                    Toast.makeText(MainActivity2.this, "Added Match Details Successfully", Toast.LENGTH_SHORT).show();
                    finish();
                    startActivity(getIntent());
                }
            }
        });


        button_view.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity2.this, MainActivity3.class);
                startActivity(intent);
            }
        });

    }
}