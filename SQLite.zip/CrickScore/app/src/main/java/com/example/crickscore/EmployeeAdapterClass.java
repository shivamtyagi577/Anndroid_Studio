package com.example.crickscore;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class EmployeeAdapterClass extends RecyclerView.Adapter<EmployeeAdapterClass.ViewHolder> {

    List<EmployeeModelClass> employee;
    Context context;
    DatabaseHelperClass databaseHelperClass;

    public EmployeeAdapterClass(List<EmployeeModelClass> employee, Context context) {
        this.employee = employee;
        this.context = context;
        databaseHelperClass = new DatabaseHelperClass(context);
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View view = layoutInflater.inflate(R.layout.employee_item_list,parent,false);
        ViewHolder viewHolder = new ViewHolder(view);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull final ViewHolder holder, final int position) {
        final EmployeeModelClass employeeModelClass = employee.get(position);

        holder.textViewID.setText(Integer.toString(employeeModelClass.getId()));
        holder.editText_t1.setText(employeeModelClass.getT1());
        holder.editText_st1.setText(employeeModelClass.getSt1());
        holder.editText_t2.setText(employeeModelClass.getT2());
        holder.editText_st2.setText(employeeModelClass.getSt2());
        holder.editText_status.setText(employeeModelClass.getStatus());
        holder.editText_date.setText(employeeModelClass.getDate());

        holder.button_Edit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String stringt1 = holder.editText_t1.getText().toString();
                String stringst1 = holder.editText_st1.getText().toString();
                String stringt2 = holder.editText_t2.getText().toString();
                String stringst2 = holder.editText_st2.getText().toString();
                String stringstatus = holder.editText_status.getText().toString();
                String stringdate = holder.editText_date.getText().toString();



                databaseHelperClass.updateEmployee(new EmployeeModelClass(employeeModelClass.getId(),stringt1,stringst1,stringt2,stringst2,stringstatus,stringdate));
                notifyDataSetChanged();
                ((Activity) context).finish();
                context.startActivity(((Activity) context).getIntent());
            }
        });

        holder.button_delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                databaseHelperClass.deleteEmployee(employeeModelClass.getId());
                employee.remove(position);
                notifyDataSetChanged();
            }
        });

    }

    @Override
    public int getItemCount() {
        return employee.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder{
        TextView textViewID;
        EditText editText_t1,editText_st1, editText_t2, editText_st2, editText_status, editText_date;
        Button button_Edit;
        Button button_delete;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            textViewID = itemView.findViewById(R.id.text_id);
            editText_t1 = itemView.findViewById(R.id.edittext_t1);
            editText_st1= itemView.findViewById( R.id.edittext_st1 );
            editText_t2 = itemView.findViewById( R.id.edittext_t2 );
            editText_st2 = itemView.findViewById( R.id.edittext_st2 );
            editText_status = itemView.findViewById( R.id.edittext_status );
            editText_date = itemView.findViewById( R.id.edittext_date );

            button_Edit= itemView.findViewById( R.id.button_edit );
            button_delete= itemView.findViewById( R.id.button_delete );

        }
    }
}

