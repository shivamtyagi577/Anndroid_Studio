package com.example.trend;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.PopupMenu;
import android.widget.Toast;

import com.google.android.material.bottomnavigation.BottomNavigationView;

public class MainActivity4 extends AppCompatActivity {
    private ImageView imageView10,imageView11,imageView8;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main4);
        ActionBar actionBar=getSupportActionBar();
        actionBar.setTitle("Profile Page");
        //-----------------------------------------------------------------------------------------
        imageView8=(ImageView)findViewById(R.id.imageView8);
        imageView10=(ImageView)findViewById(R.id.imageView10);
        imageView11=(ImageView)findViewById(R.id.imageView11);
        imageView8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent= new Intent(getApplicationContext(),MainActivity5.class);
                startActivity(intent);
            }
        });

        imageView10.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                PopupMenu popup = new PopupMenu(MainActivity4.this,v);
                popup.getMenuInflater().inflate(R.menu.popup_email,popup.getMenu());
                popup.show();
                popup.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                    @Override
                    public boolean onMenuItemClick(MenuItem item) {
                        switch (item.getItemId()){
                            case R.id.mb1 :
                                Toast.makeText(MainActivity4.this,"Call me on 8126519330",Toast.LENGTH_LONG).show();
                                return true;
                            case R.id.mb2 :
                                Toast.makeText(MainActivity4.this,"Call me on 9368207629",Toast.LENGTH_LONG).show();
                                return true;

                        }
                        return false;
                    }
                });

            }
        });

        imageView11.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                PopupMenu popup = new PopupMenu(MainActivity4.this,v);
                popup.getMenuInflater().inflate(R.menu.pop_email,popup.getMenu());
                popup.show();
                popup.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                    @Override
                    public boolean onMenuItemClick(MenuItem item) {
                        switch (item.getItemId()){
                            case R.id.e1 :
                                Toast.makeText(MainActivity4.this,"Mail me on shivamtyagi577",Toast.LENGTH_LONG).show();
                                return true;
                            case R.id.e2 :
                                Toast.makeText(MainActivity4.this,"Mail me on shivam.tyagi",Toast.LENGTH_LONG).show();
                                return true;

                        }
                        return false;
                    }
                });

            }
        });



        //-----------------------------------------------------------------------------------------
        BottomNavigationView bottomNavigationView= (BottomNavigationView) findViewById(R.id.bottom_navigation);
        bottomNavigationView.setSelectedItemId(R.id.dashboard);
        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                switch(item.getItemId()){
                    case R.id.dashboard:
                        startActivity(new Intent(getApplicationContext(),MainActivity2.class));
                        overridePendingTransition(0,0);
                        return true;
                    case R.id.home:
                        startActivity(new Intent(getApplicationContext(),MainActivity3.class));
                        overridePendingTransition(0,0);

                        return true;
                    case R.id.profile:
                        return true;
                }
                return false;
            }
        });
        //----------------------------------------------------------------------------------------

    }
}