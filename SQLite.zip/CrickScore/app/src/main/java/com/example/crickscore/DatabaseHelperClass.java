package com.example.crickscore;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

public class DatabaseHelperClass extends SQLiteOpenHelper {

    //Database version
    private static final int DATABASE_VERSION = 1;
    //Database Name
    private static final String DATABASE_NAME = "DB";
    //Database Table name
    private static final String TABLE_NAME = "Matches";
    //Table columns
    public static final String ID = "id";
    public static final String TEAM1 = "Team_1";
    public static final String SCORE_T1 = "Score_Team_1";
    public static final String TEAM2 = "Team_2";
    public static final String SCORE_T2 = "Score_Team_2";
    public static final String STATUS = "Status";
    public static final String DATE = "Date";
    private SQLiteDatabase sqLiteDatabase;


    //creating table query

    private static final String
            CREATE_TABLE = "create table " + TABLE_NAME + "(" + ID +
            " INTEGER PRIMARY KEY ," + TEAM1 + " TEXT, " + SCORE_T1 + " TEXT, " + TEAM2 + " TEXT NOT NULL, " + SCORE_T2 + " TEXT ," + STATUS + " TEXT NOT NULL," + DATE + " TEXT NOT NULL);";


    //Constructor
    public DatabaseHelperClass (Context context){
        super(context,DATABASE_NAME,null,DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL(" DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(db);
    }

    //Add Employee Data
    public void addEmployee(EmployeeModelClass employeeModelClass){
        ContentValues contentValues = new ContentValues();
        contentValues.put(DatabaseHelperClass.TEAM1, employeeModelClass.getT1());
        contentValues.put(DatabaseHelperClass.SCORE_T1, employeeModelClass.getSt1());
        contentValues.put(DatabaseHelperClass.TEAM2, employeeModelClass.getT2());
        contentValues.put(DatabaseHelperClass.SCORE_T2, employeeModelClass.getSt2());
        contentValues.put(DatabaseHelperClass.STATUS, employeeModelClass.getStatus());
        contentValues.put(DatabaseHelperClass.DATE, employeeModelClass.getDate());

        sqLiteDatabase = this.getWritableDatabase();
        sqLiteDatabase.insert(DatabaseHelperClass.TABLE_NAME, null,contentValues);
    }

    public List<EmployeeModelClass> getEmployeeList(){
        String sql = "select * from " + TABLE_NAME;
        sqLiteDatabase = this.getReadableDatabase();
        List<EmployeeModelClass> storeEmployee = new ArrayList<>();
        Cursor cursor = sqLiteDatabase.rawQuery(sql,null);
        if (cursor.moveToFirst()){
            do {
                int id = Integer.parseInt(cursor.getString(0));
                String t1 = cursor.getString(1);
                String st1 = cursor.getString(2);
                String t2 = cursor.getString(3);
                String st2 = cursor.getString(4);
                String status = cursor.getString(5);
                String date = cursor.getString(6);
                storeEmployee.add(new EmployeeModelClass(id,t1,st1,t2,st2,status,date));
            }while (cursor.moveToNext());
        }
        cursor.close();
        return storeEmployee;
    }

    public void updateEmployee(EmployeeModelClass employeeModelClass){
        ContentValues contentValues = new ContentValues();
        contentValues.put(DatabaseHelperClass.TEAM1, employeeModelClass.getT1());
        contentValues.put(DatabaseHelperClass.SCORE_T1, employeeModelClass.getSt1());
        contentValues.put(DatabaseHelperClass.TEAM2, employeeModelClass.getT2());
        contentValues.put(DatabaseHelperClass.SCORE_T2, employeeModelClass.getSt2());
        contentValues.put(DatabaseHelperClass.STATUS, employeeModelClass.getStatus());
        contentValues.put(DatabaseHelperClass.DATE, employeeModelClass.getDate());
        sqLiteDatabase = this.getWritableDatabase();
        sqLiteDatabase.update(TABLE_NAME,contentValues,ID + " = ?" , new String[]
                {String.valueOf(employeeModelClass.getId())});
    }

    public void deleteEmployee(int id){
        sqLiteDatabase = this.getWritableDatabase();
        sqLiteDatabase.delete(TABLE_NAME, ID + " = ? ", new String[]
                {String.valueOf(id)});
    }

}
