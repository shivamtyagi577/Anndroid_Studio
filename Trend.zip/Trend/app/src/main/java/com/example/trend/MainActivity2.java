package com.example.trend;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;

import com.google.android.material.bottomnavigation.BottomNavigationView;

public class MainActivity2 extends AppCompatActivity {
    private ImageView imageView,imageView2,imageView3,imageView4;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
//        ActionBar actionBar=getSupportActionBar();
//        actionBar.setTitle("Home");
        ActionBar actionBar=getSupportActionBar();
        actionBar.setTitle("Dashboard");
        //-----------------------------------------------------------------------------------------
        BottomNavigationView bottomNavigationView= (BottomNavigationView) findViewById(R.id.bottom_navigation);
        bottomNavigationView.setSelectedItemId(R.id.dashboard);
        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                switch(item.getItemId()){
                    case R.id.dashboard:
                        return true;
                    case R.id.home:
                        startActivity(new Intent(getApplicationContext(),MainActivity3.class));
                        overridePendingTransition(0,0);
                        return true;
                    case R.id.profile:
                        startActivity(new Intent(getApplicationContext(),MainActivity4.class));
                        overridePendingTransition(0,0);
                        return true;
                }
                return false;
            }
        });
        //----------------------------------------------------------------------------------------

        //actionBar.setDisplayHomeAsUpEnabled(true);
        imageView = (ImageView)findViewById(R.id.imageView);
        imageView2 = (ImageView)findViewById(R.id.imageView2);
        imageView3 = (ImageView)findViewById(R.id.imageView3);
        imageView4 = (ImageView)findViewById(R.id.imageView4);

        imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String url="https://www.worthofweb.com/website-value/geeksforgeeks.org/?__cf_chl_jschl_tk__=a9797d96d54440eef2338b3ff8f9ee36eb9f9076-1614153095-0-AZaL5KDMyJmRTkIDXX8Wi6w1XpO2l6AV7iHo3-hgBQDeoxkxeSJOzIjVKUJwfWAlg8VQ9HJS9mrCb1aarbrpwvY0T_SEV_7rECCYakHmIMeE4W1sO5lbfi6RZO6ngJ5LmBUd_foB4lEMFwUUc9NYbQ9vYqwiwmXpjKEmyJ9RWHyzzirSCygKAOjRzgUTEpo8w58wMefOPeqMJpySdLeFwCPjJL_UWF8fqECP5GOVkjJ5jbNtkV8SMOMey_-Dg2uUrHXVnELlB8QS3PS-CDQROYW_bLYW9jBTw0j49n8UkTRF9M0noiIiQ4in2E9Weh8bvKNgl0a9H2f9WCu8Y9n8KAVsvtJ6rLSWw6mgu1VPstVlDmESdCy7PlGCVUKbS2Y381K0XrEUCRfhQTLgHb8bbqd4RLKr1EPwoHyN9sYKk2Hs";
                Intent intent=new Intent(Intent.ACTION_VIEW);
                intent.setData(Uri.parse(url));
                startActivity(intent);
            }
        });

        imageView2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String url="https://www.hackerrank.com/about-us";
                Intent intent=new Intent(Intent.ACTION_VIEW);
                intent.setData(Uri.parse(url));
                startActivity(intent);
            }
        });

        imageView3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String url="http://www.programmr.com/in_the_press";
                Intent intent=new Intent(Intent.ACTION_VIEW);
                intent.setData(Uri.parse(url));
                startActivity(intent);
            }
        });

        imageView4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String url="https://www.pathrise.com/guides/a-review-of-w3schools-as-a-web-dev-resource/";
                Intent intent=new Intent(Intent.ACTION_VIEW);
                intent.setData(Uri.parse(url));
                startActivity(intent);
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main,menu);
        return super.onCreateOptionsMenu(menu);
    }
}