package com.example.ironmanbroadcastreciever;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Build;
import android.widget.Toast;

import androidx.core.app.NotificationCompat;

public class HOPReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent i) {
        if(i.getAction().equals("android.intent.action.BATTERY_LOW")){
            abc(context,"Battery","LOW",0);
            Toast.makeText(context,"Battery is LOW",Toast.LENGTH_LONG).show();
        }
        else if(i.getAction().equals("android.intent.action.ACTION_POWER_CONNECTED")){
            abc(context,"Power","Connected",1);
            Toast.makeText(context,"Power is Connected",Toast.LENGTH_LONG).show();
        }
        else if(i.getAction().equals("android.intent.action.ACTION_POWER_DISCONNECTED")){
            abc(context,"Power","Disconnected",2);
            Toast.makeText(context,"Power is Disconnected",Toast.LENGTH_LONG).show();
        }
        else if(i.getAction().equals("android.intent.action.HEADSET_PLUG")){
            abc(context,"EAR PHONES","PLUGED",3);
            Toast.makeText(context,"JBL EarPhone is Pluged",Toast.LENGTH_LONG).show();
        }
        else if(i.getAction().equals("android.intent.action.SCREEN_OFF")){
            abc(context,"Screen","Off",4);
            Toast.makeText(context,"Mobile Screen is OFFF",Toast.LENGTH_LONG).show();
        }
        else if(i.getAction().equals("android.intent.action.SCREEN_ON")){
            abc(context,"Screen","On",5);
            Toast.makeText(context,"Mobile Screen is ONNNN",Toast.LENGTH_LONG).show();
        }
        else if(i.getAction().equals("android.intent.action.BOOT_COMPLETED")){
            abc(context,"Screen","On",5);
            Toast.makeText(context,"Boot Completed",Toast.LENGTH_LONG).show();
        }



        // TODO: This method is called when the BroadcastReceiver is receiving
        // an Intent broadcast.
        //throw new UnsupportedOperationException("Not yet implemented");
    }

    private void abc(Context context,String body,String title, int notifyid){
        Intent i =  new Intent(context , MainActivity2.class);
        PendingIntent pi = PendingIntent.getActivity(context,0,i,0);
        NotificationManager notificationManager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.O){
            NotificationChannel notificationChannel = new NotificationChannel("1","MyNotifications",NotificationManager.IMPORTANCE_HIGH);
            notificationChannel.setDescription(body);
            notificationChannel.enableLights(true);
            notificationChannel.setLightColor(Color.RED);
            notificationChannel.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
            notificationChannel.setVibrationPattern(new long[]{0,1000,500,1000});
            notificationChannel.enableVibration(true);
            notificationManager.createNotificationChannel(notificationChannel);

        }

        NotificationCompat.Builder notificationBuilder = new NotificationCompat.Builder(context,"1");
         notificationBuilder.setAutoCancel(true)
                 .setDefaults(Notification.DEFAULT_ALL)
                 .setWhen(System.currentTimeMillis())
                 .setSmallIcon(R.drawable.notify)
                 .setTicker("Hearty365")
                 .setPriority(Notification.PRIORITY_MAX)
                 .setOngoing(true)
                 .setContentTitle((title))
                 .setColor((context.getResources().getColor(R.color.purple_200)))
                 .setContentInfo("Info")
                 .setContentIntent(pi);
         notificationManager.notify(notifyid,notificationBuilder.build());
    }
}