package com.example.mycalculator;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    private TextView textview1,textview2;
    private double first;
    private double second;
    private double result;
    private String operations;
    private String answer,temp;
    public int val=0;
    private String text="";
    private Button button1,button2,button3,button4,button5,button6,button7,button8,button9,button0,buttonPercent,buttonDivide,buttonMultiply,buttonSub,buttonAdd,buttonDot,buttonEqual,buttonClear,buttonBackSpace;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        textview1=(TextView)findViewById(R.id.textView1);
        textview2=(TextView)findViewById(R.id.textView2);
        button0=(Button)findViewById(R.id.button0);
        button1=(Button)findViewById(R.id.button1);
        button2=(Button)findViewById(R.id.button2);
        button3=(Button)findViewById(R.id.button3);
        button4=(Button)findViewById(R.id.button4);
        button5=(Button)findViewById(R.id.button5);
        button6=(Button)findViewById(R.id.button6);
        button7=(Button)findViewById(R.id.button7);
        button8=(Button)findViewById(R.id.button8);
        button9=(Button)findViewById(R.id.button9);
        buttonPercent=(Button)findViewById(R.id.buttonPercent);
        buttonDivide=(Button)findViewById(R.id.buttonDivide);
        buttonDot=(Button)findViewById(R.id.buttonDot);
        buttonMultiply=(Button)findViewById(R.id.buttonMultiply);
        buttonSub=(Button)findViewById(R.id.buttonSub);
        buttonBackSpace=(Button)findViewById(R.id.buttonBackSpace);
        buttonAdd=(Button)findViewById(R.id.buttonAdd);
        buttonEqual=(Button)findViewById(R.id.buttonEqual);
        buttonClear=(Button)findViewById(R.id.buttonClear);

        buttonClear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                textview1.setText(null);
                textview2.setText(null);
            }
        });
        button0.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//               String text;
//               text= new StringBuilder().append(textview2.getText().toString()).append(button0.toString()).toString();
//               textview2.setText(text);
                textview2.setText(textview2.getText()+"0");
            }
        });
        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //val=1;

                //temp=Integer.toString(val);
                //text += temp;
                //textview2.setText(text);
                //text = String.format("%s%s", textview2.getText().toString(), button1.toString());
                //textview2.setText(Integer.toString(val));
                textview2.setText(textview2.getText()+"1");
            }
        });
        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //String text="";
//                text=textview2.getText().toString() + button2.toString();
//                textview2.setText(text);
                textview2.setText(textview2.getText()+"2");
            }
        });
        button3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                String text;
//                text=textview2.getText().toString() + button3.toString();
//                textview2.setText(text);
                textview2.setText(textview2.getText()+"3");
            }
        });
        button4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                String text;
//                text=textview2.getText().toString() + button4.toString();
//                textview2.setText(text);
                textview2.setText(textview2.getText()+"4");
            }
        });
        button5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                String text;
//                text=textview2.getText().toString() + button5.toString();
//                textview2.setText(text);
                textview2.setText(textview2.getText()+"5");
            }
        });
        button6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                String text;
//                text=textview2.getText().toString() + button6.toString();
//                textview2.setText(text);
                textview2.setText(textview2.getText()+"6");
            }
        });
        button7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                String text;
//                text=textview2.getText().toString() + button7.toString();
//                textview2.setText(text);
                textview2.setText(textview2.getText()+"7");
            }
        });
        button8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                String text;
//                text=textview2.getText().toString() + button8.toString();
//                textview2.setText(text);
                textview2.setText(textview2.getText()+"8");
            }
        });
        button9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                String text;
//                text=textview2.getText().toString() + button9.toString();
//                textview2.setText(text);
                textview2.setText(textview2.getText()+"9");
            }
        });
        buttonDot.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                String text;
//                text=textview2.getText().toString()+buttonDot.getText().toString();
//                textview2.setText(text);
                textview2.setText(textview2.getText()+".");
            }
        });
        buttonBackSpace.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String BackSpace=null;
                if(textview2.getText().length()>0){
                    StringBuilder stringbuilder=new StringBuilder(textview2.getText());
                    stringbuilder.deleteCharAt(textview2.getText().length()-1);
                    BackSpace=stringbuilder.toString();
                    textview2.setText(BackSpace);
                }
            }
        });
        /// code of operator

        buttonPercent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String primary;
                first=Double.parseDouble((String) textview2.getText());
                primary=String.format("%.2f",first);
                textview1.setText(primary);
                textview2.setText("");
                operations="%";
            }
        });
        buttonSub.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String primary;
                first=Double.parseDouble((String) textview2.getText());
                primary=String.format("%.2f",first);
                textview1.setText(primary);
                textview2.setText("");
                operations="-";
            }
        });
        buttonMultiply.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String primary;
                first=Double.parseDouble((String) textview2.getText());
                primary=String.format("%.2f",first);
                textview1.setText(primary);
                textview2.setText("");
                operations="*";
            }
        });
        buttonDivide.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String primary;
                first=Double.parseDouble((String) textview2.getText());
                primary=String.format("%.2f",first);
                textview1.setText(primary);
                textview2.setText("");
                operations="/";
            }
        });
        buttonAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String primary;
                first=Double.parseDouble((String) textview2.getText());
                primary=String.format("%.2f",first);
                textview1.setText(primary);
                textview2.setText("");
                operations="+";
            }
        });

        // code for equal

        buttonEqual.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                second=Double.parseDouble((String) textview2.getText());
                if(operations=="+"){
                    result=first+second;
                    answer=String.format("%2f",result);
                    textview2.setText(answer);
                    textview1.setText(null);
                }
                if(operations=="-"){
                    result=first-second;
                    answer=String.format("%2f",result);
                    textview2.setText(answer);
                    textview1.setText(null);
                }
                if(operations=="*"){
                    result=first*second;
                    answer=String.format("%2f",result);
                    textview2.setText(answer);
                    textview1.setText(null);
                }
                if(operations=="/"){
                    result=first/second;
                    answer=String.format("%2f",result);
                    textview2.setText(answer);
                    textview1.setText(null);
                }
                if(operations=="%"){
                    result=first%second;
                    answer=String.format("%2f",result);
                    textview2.setText(answer);
                    textview1.setText(null);
                }
            }
        });


    }
}