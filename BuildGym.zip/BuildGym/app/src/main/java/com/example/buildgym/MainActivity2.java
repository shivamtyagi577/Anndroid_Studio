package com.example.buildgym;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity2 extends AppCompatActivity {
    private Button button2;
    private EditText editText1,editText2,editText3,editText4,editText5;
    private TextView textView;
    Spinner spinner;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        button2 = (Button) findViewById(R.id.button2);
       //editText1=(EditText)findViewById(R.id.editText1);
        editText2=(EditText)findViewById(R.id.editText2);
        editText3=(EditText)findViewById(R.id.editText3);
        editText4=(EditText)findViewById(R.id.editText4);
        editText5=(EditText)findViewById(R.id.editText5);
        //editText6=(EditText)findViewById(R.id.editText6);
        textView=(TextView)findViewById(R.id.textView3) ;
        spinner=(Spinner)findViewById(R.id.spinner1);

        populateSpinnerLevel();

        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (editText2.getText().toString().isEmpty() || editText3.getText().toString().isEmpty() ||
                        editText4.getText().toString().isEmpty() ||
                        editText5.getText().toString().isEmpty()) {
                    Toast.makeText(MainActivity2.this, "Fill up your details",
                            Toast.LENGTH_LONG).show();
                }
                else {
                    Intent intent = new Intent(getApplicationContext(),MainActivity3.class);
                    startActivity(intent);
                }
            }
        });
    }

    private void populateSpinnerLevel() {
        ArrayAdapter<String> leveladapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item,getResources().getStringArray(R.array.level));
        leveladapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(leveladapter);
    }
}